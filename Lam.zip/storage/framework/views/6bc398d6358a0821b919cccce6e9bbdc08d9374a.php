	<div class="widget">
		<div class="social-widget">
			<div class="item">
				<div class="item-header">
					<a href="<?php echo e($adverts_center[0]->link); ?>"><img src="<?php echo e(url('public/img/advert/'.$adverts_center[0]->img)); ?>" alt="No image" /></a>
				</div>
			</div>
		</div>
	</div>


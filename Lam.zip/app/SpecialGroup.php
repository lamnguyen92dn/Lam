<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecialGroup extends Model
{
    //
    protected $table = "specialgroup";
    public $timestamps = false; 
    
}

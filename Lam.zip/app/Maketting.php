<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maketting extends Model
{
    //
    protected $table = "makettings";
}

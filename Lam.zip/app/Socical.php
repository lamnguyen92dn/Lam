<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Socical extends Model
{
    //
    protected $table = "socicals";
    public $timestamps = false; 
}

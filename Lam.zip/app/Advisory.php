<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advisory extends Model
{
    //
    protected $table = "advisory";
    public $timestamps = true; 
    
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shippings extends Model
{
    //
    protected $table = "shippings";
    public $timestamps = false;
}

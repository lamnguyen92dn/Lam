<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wards extends Model
{
    //
    protected $table = "Wards";
    public $timestamps = false;
}

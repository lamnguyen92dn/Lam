<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productimage extends Model
{
    //
    protected $table = "productimage";
}
